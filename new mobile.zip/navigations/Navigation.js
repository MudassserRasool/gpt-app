import { createDrawerNavigator } from "@react-navigation/drawer";
import ChatBoot from "../screens/ChatBoot/ChatBoot";
import { NavigationContainer } from "@react-navigation/native";
import AuthNavigation from "./AuthNavigation";
import DrawerView from "../components/DrawerView/DrawerView";
import { createNativeStackNavigator } from "@react-navigation/native-stack"; // Correct import
import NewChatButton from "../components/NewChatButton/NewChatButton";
import {
  blackColor,
  blueGray,
  darkBlueColor,
  mainBlackColor,
  slateGray,
} from "../style";
import { StyleSheet, Text } from "react-native";
import CronosAiText from "../components/CronosAiText/CronosAiText";
import { useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

const DrawerNavigation = () => {
  return (
    <Drawer.Navigator
      screenOptions={{ headerTintColor: "white" }}
      drawerContent={(props) => <DrawerView {...props} />}
    >
      <Drawer.Screen
        options={{
          headerShown: true,
          headerStyle: { backgroundColor: blueGray }, // Add this line
          headerRight: () => <NewChatButton />,
          headerTitle: () => <CronosAiText />,
        }}
        name="ChronosAI"
        component={ChatBoot}
      />
    </Drawer.Navigator>
  );
};

export function MainStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="AppDrawerStack" component={DrawerNavigation} />
    </Stack.Navigator>
  );
}

export default function Navigation() {
  const [user, setUser] = useState(null);
  const signInWithGoogle = async () => {
    try {
      const userJSON = await AsyncStorage.getItem("@google_user");
      setUser(userJSON ? JSON.parse(userJSON) : null);
    } catch (error) {
      console.error("Error retrieving user data from AsyncStorage:", error);
    }
  };

  useEffect(() => {
    signInWithGoogle();
  }, []);

  return (
    <NavigationContainer>
      {user ? <MainStack /> : <AuthNavigation />}
    </NavigationContainer>
  );
}
