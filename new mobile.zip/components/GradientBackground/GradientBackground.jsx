import { View, Text, ImageBackground } from "react-native";
import React from "react";
import { blueGray } from "../../style";

const GradientBackground = ({ children, image }) => {
  return <View style={{ flex: 1, backgroundColor: blueGray }}>{children}</View>;
};

export default GradientBackground;
