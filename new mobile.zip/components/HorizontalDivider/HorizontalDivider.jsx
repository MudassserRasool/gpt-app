import { Image } from "react-native";
import React from "react";

const HorizontalDivider = ({ width }) => {
  return (
    <Image
      source={require("../../assets/Elements/Divider.png")}
      style={{ width: `${width}%`, resizeMode: "contain" }}
    />
  );
};

export default HorizontalDivider;
