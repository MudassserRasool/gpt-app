import { View, Text, StyleSheet } from "react-native";
import React from "react";

const CronosAiText = () => {
  return (
    <Text style={styles.text}>
      Cronos<Text style={{ fontWeight: "700" }}>AI</Text>
    </Text>
  );
};

export default CronosAiText;

const styles = StyleSheet.create({
  text: {
    fontFamily: "Roboto",
    fontSize: 18,
    color: "white",
    fontWeight: "300",
  },
});
