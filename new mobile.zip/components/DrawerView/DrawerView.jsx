import { View, Text, Image, TouchableOpacity } from "react-native";
import React from "react";
import { grayColor, lightSlateGray, skyColor, slateGray } from "../../style.js";
import styles from "./DrawerView.style.js";
import * as Icon from "react-native-feather";
const DrawerView = () => {
  return (
    <View style={styles.container}>
      <View style={styles.sectionContainer}>
        {/* start image row */}
        <View style={styles.profileRow}>
          <Image
            source={require("../../assets/Images/Chat/UserImage.png")}
            style={{ width: 50, height: 50 }}
          />
          <Text style={styles.boldText}>SanaUllah</Text>
        </View>
        {/* end image row */}
        <View
          style={{
            borderWidth: 1,
            borderColor: slateGray,
            width: "90%",
            marginRight: "auto",
          }}
        ></View>

        {/* start History */}
        <Text style={styles.boldText}>Recent</Text>

        <View style={styles.historyContainer}>
          <TouchableOpacity style={styles.row}>
            <Icon.MessageSquare color={lightSlateGray} width={20} height={20} />
            <Text style={styles.dimText}>Wirefram Descrp...</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={[styles.sectionContainer, { marginBottom: 30 }]}>
        <TouchableOpacity style={styles.row}>
          <Icon.HelpCircle color={"#fff"} width={21} height={21} />
          <Text style={styles.normalText}>Help</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.row}>
          <Icon.LogOut color={"#fff"} width={21} height={21} />
          <Text style={styles.normalText}>Logout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default DrawerView;
