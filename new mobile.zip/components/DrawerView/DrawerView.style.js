import { StyleSheet } from "react-native";
import { blueGray, lightSlateGray } from "../../style";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: blueGray,
    justifyContent: "space-between",
    paddingLeft: 25,
  },
  sectionContainer: {
    gap: 20,
  },
  profileRow: {
    flexDirection: "row",
    alignItems: "center",

    marginTop: 35,
    gap: 10,
  },
  boldText: {
    fontFamily: "Roboto",
    fontSize: 16,
    fontWeight: "700",
    color: "#fff",
  },
  normalText: {
    fontFamily: "Roboto",
    fontSize: 16,
    fontWeight: "400",
    color: "#fff",
  },
  dimText: {
    fontFamily: "Roboto",
    fontSize: 15,
    fontWeight: "400",
    color: lightSlateGray,
  },
  historyContainer: {
    gap: 10,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
});
export default styles;
