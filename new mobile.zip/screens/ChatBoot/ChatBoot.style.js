import { StyleSheet } from "react-native";
import {
  darkSlateGray,
  grayColor,
  lightBlueColor,
  lightSlateGray,
  skyColor,
  slateGray,
} from "../../style";

const styles = StyleSheet.create({
  sendButtonBg: {
    backgroundColor: "#fff",
    borderRadius: 50,
    padding: 10,
    height: 51,
    width: 51,
    alignItems: "center",
    justifyContent: "center",
  },
  messageChatInput: {
    display: "flex",
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 4,
    paddingBottom: 2,
    marginTop: 2,
    width: "95%",
    marginLeft: "auto",
    marginRight: "auto",
  },
  inputContainer: {
    flexDirection: "row",
    flex: 1,
    alignItems: "center",
    padding: 2,
    borderRadius: 50,
    borderWidth: 1,
    borderColor: slateGray,
    width: "90%",
    alignSelf: "center",
    marginBottom: 0,
    padding: 5,
    backgroundColor: darkSlateGray,
  },
  sendButtonAndLine: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    marginRight: 5,
  },
  //   messageChatInputBg: {},
  verticalLine: {
    height: 35,
    width: 1,
    backgroundColor: "#E5E6E9",
    marginRight: 10,
    marginLeft: 5,
  },

  messageContainer: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "flex-start",
    marginBottom: 30,
  },

  messageBg: {
    display: "flex",
    flexDirection: "column",
    width: "95%",
  },
  messageText: {
    color: lightSlateGray,
    fontSize: 15,
    fontFamily: "Roboto",
    fontStyle: "normal",
    fontWeight: "400",
    letterSpacing: -0.3,
    padding: 2,
    borderRadius: 40,
    lineHeight: 26,
  },
  dividerContainer: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    marginLeft: 65,
    marginVertical: 15,
  },
  chatImageAndNameRow: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  aiChatActionRow: {
    marginTop: 5,
    marginLeft: 50,
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  chatImage: {
    width: 34,
    height: 34,
  },
  animationContainer: {
    width: "15%",
    height: "15%",
    marginLeft: 40,
  },
  buttonContainer: {
    paddingTop: 20,
  },
});

export default styles;
export const iconSize = 18;
