import { Alert, Button, Image, Linking } from "react-native";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Dimensions,
} from "react-native";
import React, { useState, useRef, useEffect } from "react";
import styles, { iconSize } from "./ChatBoot.style";
import * as Icon from "react-native-feather";
import LottieView from "lottie-react-native";
import * as Clipboard from "expo-clipboard";
import { darkBlueColor, lightSlateGray, silver } from "../../style";
import GradientBackground from "../../components/GradientBackground/GradientBackground";
import CronosAiText from "../../components/CronosAiText/CronosAiText";
import AnimatedTyping from "../../components/AnimatedTyping/AnimatedTyping";
import * as Speech from "expo-speech";
import { OPEN_AI_API_KEY } from "@env";
import {
  androidClientId,
  iosClientId,
  webClientId,
} from "../../constants/authCredentials";
// import { gptApiKey } from "../../constants/chatBoot";

const ChatBoot = () => {
  const [userMessage, setUserMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const scrollViewRef = useRef();
  const [conversationActive, setConversationActive] = useState(true);
  const [lastUserMessage, setLastUserMessage] = useState("");

  // start snackbar
  const [loading, setLoading] = useState(false);
  // end snackbar
  const animation = useRef(null);
  const speak = (text) => {
    Speech.speak(text);
  };
  useEffect(() => {
    scrollViewRef.current.scrollToEnd({ animated: true });
  }, [messages]);
  const messageSent = [
    {
      role: "system",
      content: "Hello! How can I help you today?",
    },
    { role: "user", content: userMessage },
  ];
  const fetchAIResponse = async () => {
    if (userMessage.trim() === "") return;

    setLoading(true);
    try {
      const result = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${"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"}`,
          "OpenAI-Beta": "assistants=v1",
        },
        body: JSON.stringify({
          model: "gpt-3.5-turbo",
          messages: messageSent,
          max_tokens: 150,
        }),
      });

      const data = await result.json();
      console.log(data);
      if (data && data.choices && data.choices[0] && data.choices[0].message) {
        const newMessage = {
          text: data.choices[0].message.content,
          time: new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
          type: "bot",
        };

        setMessages((prevMessages) => [...prevMessages, newMessage]);
      } else {
        throw new Error("API request failed " + data.error.code);
      }
    } catch (error) {
      console.error(error);
      Alert.alert(
        "Error",
        "Unable to chat with AI at the moment. Please try again later."
      );
      setConversationActive(false);
    } finally {
      setLoading(false);
      setUserMessage("");
    }
  };

  // Use the fetchAIResponse function to send messages when the button is pressed
  const sendMessage = () => {
    if (!conversationActive || userMessage.trim() === "") return;

    const userMsg = {
      userMessage: userMessage,
      time: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
      type: "user",
    };
    setMessages((prevMessages) => [...prevMessages, userMsg]);
    setLastUserMessage(userMessage);
    fetchAIResponse();
  };
  const getVerticalOffset = () => {
    const { height } = Dimensions.get("window");
    return height >= 812 ? 95 : 45;
  };

  console.log(androidClientId, iosClientId, webClientId);
  return (
    <View style={{ flex: 1, backgroundColor: darkBlueColor }}>
      <GradientBackground>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : ""}
          keyboardVerticalOffset={
            Platform.OS === "ios" ? getVerticalOffset() : 0
          }
          style={{ flex: 1, flexDirection: "column-reverse", marginBottom: 10 }}
        >
          {/* start input field to send message------------------ */}
          <View
            style={[
              styles.messageChatInput,
              { opacity: conversationActive ? 1 : 0.5 },
            ]}
          >
            <View style={styles.inputContainer}>
              <TextInput
                placeholder="Type here..."
                style={{
                  marginLeft: 8,
                  flex: 1,
                  padding: 7,
                  color: "#fff",
                }}
                placeholderTextColor={silver}
                value={userMessage}
                onChangeText={(text) => setUserMessage(text)}
                onSubmitEditing={sendMessage}
              />

              <View style={styles.sendButtonAndLine}>
                <TouchableOpacity>
                  <Icon.Mic
                    height="25"
                    width="25"
                    color={silver}
                    style={{ marginRight: 2 }}
                  />
                </TouchableOpacity>
              </View>
            </View>
            <TouchableOpacity
              style={styles.sendButtonBg}
              onPress={sendMessage}
              // disabled={!conversationActive}
            >
              <Icon.ArrowRight color={"black"} />
            </TouchableOpacity>
          </View>
          {/* end input field to send message------------------ */}

          <ScrollView
            onContentSizeChange={() => {
              scrollViewRef.current.scrollToEnd({ animated: true });
            }}
            ref={scrollViewRef}
            style={{ margin: 20 }}
          >
            {messages.map((message, index) => {
              return (
                <View key={index}>
                  {message.userMessage && (
                    <View key={index} style={styles.messageContainer}>
                      <View style={styles.messageBg}>
                        <View style={styles.chatImageAndNameRow}>
                          <Image
                            source={require("../../assets/Images/Chat/UserImage.png")}
                            style={styles.chatImage}
                          />
                          <Text
                            style={[styles.messageText, { fontWeight: 700 }]}
                          >
                            You
                          </Text>
                        </View>
                        <Text
                          style={[
                            styles.messageText,
                            Platform.OS === "ios" && {
                              overflow: "hidden",
                            },
                            {
                              marginLeft: 44,
                            },
                          ]}
                        >
                          {/* {message.userMessage} */}
                          <AnimatedTyping
                            key={message.userMessage}
                            text={[message.userMessage]}
                            color={lightSlateGray}
                            fontSize={15}
                            fontFamily={"Roboto"}
                            fontStyle={"normal"}
                            fontWeight={"400"}
                            letterSpacing={-0.3}
                            padding={2}
                            borderRadius={40}
                            lineHeight={26}
                          />
                        </Text>
                      </View>
                    </View>
                  )}

                  {message.text && (
                    <View style={styles.messageContainer}>
                      {/* start user message */}
                      <View style={styles.messageBg}>
                        <View style={styles.chatImageAndNameRow}>
                          <Image
                            source={require("../../assets/Images/Chat/AiChat.png")}
                            style={styles.chatImage}
                          />
                          <CronosAiText />
                        </View>
                        <Text
                          style={[
                            styles.messageText,
                            Platform.OS === "ios" && {
                              overflow: "hidden",
                            },
                            {
                              marginLeft: 45,
                            },
                          ]}
                        >
                          {/* {message.text} */}
                          <AnimatedTyping
                            key={message.text}
                            text={[message.text]}
                            color={lightSlateGray}
                            fontSize={15}
                            fontFamily={"Roboto"}
                            fontStyle={"normal"}
                            fontWeight={"400"}
                            letterSpacing={-0.3}
                            padding={2}
                            borderRadius={40}
                            lineHeight={26}
                          />
                        </Text>
                        <View style={styles.aiChatActionRow}>
                          <TouchableOpacity
                            onPress={() =>
                              Clipboard.setStringAsync(message.text)
                            }
                          >
                            <Image
                              source={require("../../assets/Icons/ChatBoot/Copy.png")}
                              style={{
                                width: 14,
                                height: 14,
                              }}
                            />
                          </TouchableOpacity>
                          <TouchableOpacity
                            onPress={() => {
                              setUserMessage(lastUserMessage);
                              sendMessage();
                            }}
                          >
                            <Image
                              source={require("../../assets/Icons/ChatBoot/Reload.png")}
                              style={{
                                resizeMode: "contain",
                                width: 15,
                                height: 15,
                              }}
                            />
                          </TouchableOpacity>
                          <TouchableOpacity onPress={() => speak(message.text)}>
                            <Image
                              source={require("../../assets/Icons/ChatBoot/Speaker.png")}
                              style={{
                                resizeMode: "contain",
                                width: 17,
                                height: 17,
                              }}
                            />
                          </TouchableOpacity>
                        </View>
                      </View>

                      {/* end user message */}
                    </View>
                  )}
                </View>
              );
            })}

            {loading && (
              <View style={styles.animationContainer}>
                <LottieView
                  autoPlay
                  ref={animation}
                  style={{
                    width: 55,
                    height: 55,
                  }}
                  source={require("../../assets/Animations/Waiting.json")}
                />
              </View>
            )}
          </ScrollView>
        </KeyboardAvoidingView>
      </GradientBackground>
    </View>
  );
};

export default ChatBoot;

//new
