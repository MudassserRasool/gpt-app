import { View, Text } from "react-native";
import React from "react";

const Register = () => {
  return (
    <View>
      <Text>Register</Text>
    </View>
  );
};

export default Register;
