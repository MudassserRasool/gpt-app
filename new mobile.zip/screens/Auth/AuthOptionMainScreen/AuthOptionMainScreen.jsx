import React, { useState, useEffect } from "react";
import { Text, View } from "react-native";
import AnimatedTyping from "../../../components/AnimatedTyping/AnimatedTyping";
import { texts } from "../../../constants";
import {
  animationTextColor,
  animationBgColor,
  skyColor,
  lightBlueColor,
  darkBlueColor,
  slateGray,
  blueGray,
} from "../../../style";
import styles from "./AuthOptionMainScreen.style";
import ButtonRounded from "../../../components/ButtonRounded/ButtonRounded";
import GoogleLoginButton from "../../../components/GoogleLoginButton/GoogleLoginButton";
import { useNavigation } from "@react-navigation/native";
import HorizontalDivider from "../../../components/HorizontalDivider/HorizontalDivider";
const AuthOptionMainScreen = () => {
  const [index, setIndex] = useState(0);
  const [color, setColor] = useState(animationBgColor[0]);
  const [textColor, setTextColor] = useState(animationTextColor[0]);
  const [text, setText] = useState(texts[0]);
  const navigation = useNavigation();

  useEffect(() => {
    const interval = setInterval(() => {
      const newIndex = (index + 1) % animationBgColor.length;
      setIndex(newIndex);
      setColor(animationBgColor[newIndex]);
      setTextColor(animationTextColor[newIndex]);
      setText(texts[newIndex % texts.length]);
    }, 5000);

    return () => clearInterval(interval);
  }, [index]);

  return (
    <View style={[styles.container, { backgroundColor: color }]}>
      <View style={styles.centerContent}>
        <View style={styles.animationTextRow}>
          {/* <AnimatedTyping key={text} text={[text]} color={textColor} /> */}
          <AnimatedTyping
            key={text}
            text={[text]}
            color={textColor}
            fontSize={30}
            fontFamily={"Roboto"}
            fontStyle={"normal"}
            fontWeight={"700"}
            letterSpacing={-0.3}
            padding={2}
            borderRadius={40}
            lineHeight={26}
          />

          <View
            style={[
              styles.circle,
              {
                backgroundColor: textColor,
              },
            ]}
          ></View>
        </View>
      </View>

      {/* start buttonContainer */}
      <View style={styles.buttonContainer}>
        <GoogleLoginButton
          buttonBgColor={"white"}
          buttonBorder={"white"}
          textColor="black"
        />
        <ButtonRounded
          handelPress={() => console.log("first button pressed")}
          buttonBgColor={slateGray}
          buttonBorder={slateGray}
          textColor="white"
          text="Sign up with Email"
        />
        {/* <View style={styles.horizontalDivider}></View> */}
        <HorizontalDivider width={50} />
        <ButtonRounded
          handelPress={() => navigation.navigate("Login")}
          buttonBgColor={blueGray}
          buttonBorder={slateGray}
          textColor={"white"}
          text="Sign In"
        />
      </View>
    </View>
  );
};

export default AuthOptionMainScreen;
