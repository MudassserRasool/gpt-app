import { StyleSheet } from "react-native";
import { blueGray, darkBlueColor, lightBlueColor } from "../../../style";

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  animationTextRow: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    gap: 5,
    alignItems: "flex-end",
  },
  circle: {
    width: 35,
    height: 35,
    borderRadius: 50,
  },
  centerContent: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  buttonContainer: {
    backgroundColor: blueGray,
    justifyContent: "flex-end",
    alignItems: "center",
    width: "100%",
    padding: 25,
    gap: 14,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },
  horizontalDivider: {
    width: "92%",
    height: 2,
    backgroundColor: lightBlueColor,
  },
});
export default styles;
