import { StyleSheet } from "react-native";
import { blackColor, lightBlueColor, lightColor } from "../../style";

const styles = StyleSheet.create({
  logo: {
    width: 82,
    height: 82,
  },
  screenHeading: {
    color: "white",
    fontSize: 27,
    fontWeight: "700",
    marginTop: 10,
  },
  formContainer: {
    width: "87%",
    display: "flex",
    marginHorizontal: "7%",
    gap: 20,
  },
  pageTitle: {
    fontFamily: "Roboto",
    fontSize: 25,
    fontWeight: "600",
  },
  fieldContainer: {
    display: "flex",
    gap: 5,
  },
  inputLabel: {
    fontFamily: "Roboto",
    fontSize: 14,
    fontWeight: "600",
    color: "#00004D",
  },
  inputContainer: {
    borderWidth: 1,
    padding: 10,
    borderRadius: 80,
    paddingHorizontal: 18,
  },
  input: {
    fontFamily: "Roboto",
    fontSize: 14,
  },
  verticalBar: {
    width: 1,
    height: "95%",
    backgroundColor: "#CDD1E0",
    marginHorizontal: 10,
  },
  inputError: {
    fontFamily: "Roboto",
    color: "#E72626",
    fontSize: 14,
  },
  icon: {
    position: "absolute",
    right: 15,
    top: 14,
  },
  forgetPasswordRow: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  orText: {
    fontSize: 18,
    textAlign: "center",
    marginVertical: 3,
    color: "white",
    fontWeight: "700",
  },
  forgetPasswordText: {
    fontFamily: "Roboto",
    fontSize: 14,
    fontWeight: "600",
    color: "#FB344F",
  },
  checkBoxRow: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  blueButton: {
    backgroundColor: "#fff",
    height: 48,
    width: "100%",
    borderRadius: 80,
    marginBottom: 11,
    marginLeft: "auto",
    marginRight: "auto",
    justifyContent: "center",
    alignItems: "center",
  },
  horizontalDivider: {
    width: "92%",
    height: 2,
    marginVertical: 9,
    marginLeft: "auto",
    marginRight: "auto",
    backgroundColor: lightBlueColor,
  },
  buttonText: {
    color: blackColor,
    textAlign: "center",
    fontSize: 15,
    fontFamily: "RobotoBold",
    fontStyle: "normal",
    fontWeight: "600",
    lineHeight: 22,
  },
  signInWith: {
    fontWeight: "400",
    fontSize: 11,
    color: lightColor,
    textAlign: "center",
  },
  googleButton: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
  },
  googleIcon: {
    width: 28,
    height: 28,
    display: "flex",
  },
  haveNotRow: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  haveNotText: {
    fontFamily: "Roboto",
    fontSize: 14,
    fontWeight: "600",
    color: "#999EA1",
  },
  otherPageLink: {
    fontFamily: "Roboto",
    fontSize: 14,
    fontWeight: "600",
    color: "#1C81CB",
    marginLeft: 5,
  },
});

export default styles;
const iconSize = 18;

export { iconSize };
