import {
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Dimensions,
  ScrollView,
  Alert,
  Platform,
} from "react-native";
import React, { useState, useEffect } from "react";
import { Ionicons } from "@expo/vector-icons";
import styles, { iconSize } from "./LoginAndRegister.style.js";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaView } from "react-native";
import { validateEmail } from "../../utils/helper.js";
import { url } from "../../config/config.js";
import { login } from "../../redux/slices/authSlice.js";
import { useDispatch } from "react-redux";
import AsyncStorage from "@react-native-async-storage/async-storage";
import LoadingScreen from "../../components/LoadingScreen/LoadingScreen.jsx";
import {
  blueGray,
  darkBlueColor,
  darkSlateGray,
  lightBlueColor,
  placeholderColor,
  silver,
  skyColor,
  slateGray,
} from "../../style.js";
import * as WebBrowser from "expo-web-browser";
import * as Google from "expo-auth-session/providers/google";
import {
  androidClientId,
  iosClientId,
  webClientId,
} from "../../constants/authCredentials.js";
import { DoctorLogo } from "../../assets/index.js";
import ButtonRounded from "../../components/ButtonRounded/ButtonRounded.jsx";
import GoogleLoginButton from "../../components/GoogleLoginButton/GoogleLoginButton.jsx";
import GradientBackground from "../../components/GradientBackground/GradientBackground.jsx";
import HorizontalDivider from "../../components/HorizontalDivider/HorizontalDivider.jsx";

WebBrowser.maybeCompleteAuthSession();
const Login = () => {
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });
  const [hidePassword, setHidePassword] = useState(true);
  const [checked, setChecked] = useState(false);
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const navigation = useNavigation();
  const dispatch = useDispatch();
  // const rememberedCredentials = AsyncStorage.getItem("rememberCredentials");

  useEffect(() => {
    const loadRememberedCredentials = async () => {
      const rememberedCredentialsString = await AsyncStorage.getItem(
        "rememberedCredentials"
      );
      if (rememberedCredentialsString) {
        const rememberedCredentials = JSON.parse(rememberedCredentialsString);
        setLoginData({
          email: rememberedCredentials.email,
          password: rememberedCredentials.password,
        });
        setChecked(true);
      }
    };

    loadRememberedCredentials();
  }, []);

  const handleEmailChange = (text) => {
    setLoginData({ ...loginData, email: text });

    if (isSubmitted) {
      setEmailError(validateEmail(text) ? "" : "Enter a valid email address");
    }
  };

  const handlePasswordChange = (text) => {
    setLoginData({ ...loginData, password: text });
    if (loginData.password.length > 6) {
      setPasswordError("");
      // return;
    }
  };

  const handelLogin = async () => {
    setIsSubmitted(true);
    if (!validateEmail(loginData.email)) {
      setEmailError("Enter a valid email address");
      return;
    }
    if (loginData.password.length < 6) {
      setPasswordError("Password must be at least 6 characters");
      return;
    }
    setIsLoading(true);
    const userData = {
      email: loginData.email,
      password: loginData.password,
    };

    try {
      const response = await fetch(`${url}/api/users/login`, {
        method: "POST",
        body: JSON.stringify(userData),
        headers: {
          "Content-Type": "application/json",
        },
      });

      const json = await response.json();

      if (!response.ok) {
        if (json.message === "Invalid User Email") {
          setEmailError(json.message);
        } else if (json.message === "Invalid Password") {
          setPasswordError(json.message);
        } else {
          Alert.alert("An Unknown Error occurred");
        }
      } else {
        dispatch(login({ token: json.token }));
        await AsyncStorage.setItem("userId", json.id);
        await AsyncStorage.setItem("userToken", json.token);
        const userId = await AsyncStorage.getItem("userId");
        if (checked) {
          await AsyncStorage.setItem(
            "rememberedCredentials",
            JSON.stringify(userData)
          );
        } else {
          await AsyncStorage.removeItem("rememberedCredentials");
        }
      }
    } catch (error) {
      Alert.alert("An unexpected error occurred during login");
    } finally {
      setIsLoading(false);
    }
  };

  const getVerticalOffset = () => {
    const { height } = Dimensions.get("window");
    return height >= 812 ? 30 : 10; // iPhone X and above have a height of 812 or more
  };

  // Google Sign In
  const [userInfo, setUserInfo] = useState(null);
  const [request, response, promptAsync] = Google.useAuthRequest({
    androidClientId,
    iosClientId,
    webClientId,
  });

  const signInWithGoogle = async () => {
    try {
      const userJSON = await AsyncStorage.getItem("@user");
      if (userJSON) {
        setUserInfo(JSON.parse(userJSON));
      } else if (response?.type === "success") {
        getUserInfo(response.authentication.accessToken);
      }
    } catch (error) {
      console.error("Error retrieving user data from AsyncStorage:", error);
    }
  };

  //add it to a useEffect with response as a dependency
  useEffect(() => {
    signInWithGoogle();
  }, [response]);

  const getUserInfo = async (token) => {
    if (!token) return;
    try {
      const response = await fetch(
        "https://www.googleapis.com/userinfo/v2/me",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const user = await response.json();
      console.error();
      await AsyncStorage.setItem("@user", JSON.stringify(user));
      setUserInfo(user);
    } catch (error) {
      console.error(
        "Failed to fetch user data:",
        response.status,
        response.statusText
      );
    }
  };

  //log the userInfo to see user details
  console.log("user info " + JSON.stringify(userInfo));

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <LoadingScreen isVisible={isLoading} />
      <GradientBackground>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : ""}
          keyboardVerticalOffset={
            Platform.OS === "ios" ? getVerticalOffset() : 0
          }
          style={{ flex: 1 }}
        >
          <ScrollView
            contentContainerStyle={{
              display: "flex",
              flexDirection: "column",
            }}
          >
            <View
              style={{
                display: "flex",
                alignItems: "center",
                marginTop: 75,
                marginBottom: 50,
              }}
            >
              <Image
                style={styles.logo}
                source={DoctorLogo}
                resizeMode="contain"
              />
              <Text style={styles.screenHeading}>Sign In</Text>
            </View>

            <View style={styles.formContainer}>
              <View style={styles.fieldContainer}>
                <View
                  style={{
                    ...styles.inputContainer,
                    borderColor: emailError ? "#E72626" : slateGray,
                  }}
                >
                  <TextInput
                    style={{
                      ...styles.input,
                      color: emailError ? "#E72626" : "#fff",
                    }}
                    value={loginData.email}
                    placeholderTextColor={silver}
                    placeholder="Email"
                    onChangeText={handleEmailChange}
                    maxLength={50}
                  />
                  <Ionicons
                    name={"mail"}
                    size={iconSize}
                    color={silver}
                    style={styles.icon}
                  />
                </View>
                {emailError ? (
                  <Text style={styles.inputError}>{emailError}</Text>
                ) : null}
              </View>

              <View style={styles.fieldContainer}>
                <View
                  style={{
                    ...styles.inputContainer,
                    borderColor: passwordError ? "#E72626" : slateGray,
                  }}
                >
                  <TextInput
                    style={{
                      ...styles.input,
                      color: passwordError ? "#E72626" : "#fff",
                    }}
                    value={loginData.password}
                    placeholderTextColor={silver}
                    placeholder="Password"
                    secureTextEntry={hidePassword}
                    onChangeText={handlePasswordChange}
                    maxLength={20}
                  />
                  <TouchableOpacity
                    style={styles.icon}
                    onPress={() => setHidePassword(!hidePassword)}
                  >
                    <Ionicons
                      name={hidePassword ? "eye-off" : "eye"}
                      size={iconSize}
                      color={silver}
                    />
                  </TouchableOpacity>
                </View>
                {passwordError ? (
                  <Text style={styles.inputError}>{passwordError}</Text>
                ) : null}
              </View>

              <View style={styles.forgetPasswordRow}></View>

              <ButtonRounded
                handelPress={handelLogin}
                buttonBgColor={"white"}
                buttonBorder={"white"}
                textColor={"black"}
                text="Sign In"
              />

              <Text style={styles.orText}>Or</Text>

              <View
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 10,
                }}
              >
                <GoogleLoginButton
                  buttonBgColor={slateGray}
                  buttonBorder={slateGray}
                  textColor="white"
                />
                <HorizontalDivider width={50} />
                <ButtonRounded
                  handelPress={() => navigation.navigate("Register")}
                  buttonBgColor={blueGray}
                  buttonBorder={slateGray}
                  textColor={"white"}
                  text="Sign Up"
                />
              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </GradientBackground>
    </SafeAreaView>
  );
};

export default Login;
