import googleIcon from "./Images/Auth/GoogleIcon.png";
import GradientBackgroundImage from "./Images/Background/GradientBackground.png";
import DoctorLogo from "./Icons/DoctorIcon.png";

export { googleIcon, GradientBackgroundImage, DoctorLogo };
