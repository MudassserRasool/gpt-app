const animationBgColor = ["#FFFFFF", "#3D3D3D", "#FFC1C1"];
const animationTextColor = ["#1C9AB7", "#FFFFFF", "#002A52"];

//
const blueGray = "#20242D";
const darkSlateGray = "#2B2F38";
const slateGray = "#363942";
const lightSlateGray = "#C5C7C5";
const silver = "#777777";

export {
  animationBgColor,
  animationTextColor,

  //
  blueGray,
  darkSlateGray,
  slateGray,
  lightSlateGray,
  silver,
};
