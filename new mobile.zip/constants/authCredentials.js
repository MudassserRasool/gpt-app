export const androidClientId =
  "12102086770-o536p224umhr3bs7pfl08gknvh6acfog.apps.googleusercontent.com";
export const iosClientId =
  "12102086770-0d8jqjebn8dspgkmla0fvsvqiqhtk949.apps.googleusercontent.com";
export const webClientId =
  "12102086770-huf8cgkn2c0o7pf86fjkhfqc1b2a7h91.apps.googleusercontent.com";
