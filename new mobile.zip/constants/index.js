const texts = ["Let’s break", "Need Help?", "Have Questions?"];

export { texts };
