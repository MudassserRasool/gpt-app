export const systemContent = "Hello! How can I help you today?";
export const gptApiKey = "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";
